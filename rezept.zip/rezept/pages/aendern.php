<?php
echo '
<h1>Formular</h1>
<p>Erstellt mit PHP</p>';
echo '<h2>Kursverwaltung - Personen erfassen</h2>';
include ('config.php');
/*Aufabe: Erstellen Sie ein Formular zum Erfassen von Personendaten*/
if (!isset ($_POST['saveit'])){

?>
    <form method="post">
        <label for = "vn">Vorname:</label>
        <input type="text" id="vn" name="vname" placeholder = "z.B. Maria"><br>
        <label for = "nn">Nachname:</label>
        <input type="text" id="nn" name="nname" placeholder="z.B. Musterfrau"><br>
        <label>Geschlecht:</label>
    <br>
        <input type="radio" name="ges" value="w" checked>weiblich<br>
        <input type="radio" name="ges" value="m">männlich<br>
        <input type="radio" name="ges" value="d">divers<br>
        <input type="radio" name="ges" value="x">firma<br>
    <br>
        <label>kann Vortragender sein?</label>
        <input type="checkbox" name="vor" value="w2">
    <br>
        <input type="submit" name="saveit" value="speichern">
    </form>
<?php
}
else
{
    //Daten speichern
    $vname = $_POST['vname'];
    $nname = $_POST['nname'];
    $ges = $_POST['ges'];
    $vor = 1;
    if(isset($_POST['vor'])){
        $vor = $_POST['vor'];
    }

    echo 'Folgende Daten weren gespeichert '.$vname.' '.$nname.' '.$ges.' '.$vor.'<br>';

    try
    {
        $query = "insert into person (per_vname, per_nname, per_geschlecht, per_vortragender) values(?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->execute([$vname, $nname, $ges, $vor]);
        echo 'Daten wurden gespeichert - PK '.$con->lastInsertId();
    }catch(Exception $e)
    {
        echo $e->getCode().': '.$e->getMessage();
    }
}
