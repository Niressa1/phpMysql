<?php
include 'config.php';

$rName = "";

if (isset ($_POST['saveit']))
{
    //Zutaten
    echo '<h1>'.$_POST['rName'].'</h1><p>Wählen Sie nun die Zutat und geben Sie die entsprechende Menge an:</p>';

    //Daten speichern
    $rName = $_POST['rName'];
    $zut = $_POST['zut'];

    try
    {
        $query = "insert into rezeptname (rez_name) values(?)";
        $stmt = $con->prepare($query);
        $stmt->execute([$rName]);
    }catch(Exception $e)
    {
        echo $e->getCode().': '.$e->getMessage();
    }
    ?>

    <form method="post">
        <br>
        <?php
        for($i = 1; $i <= $zut; $i++) {
            echo '<label>Zutat '.$i.' - </label>';
            echo'<label>Menge</label><input type="number" min="1" id="men" name="menge'.$i.'">';
            ?>
            <select id="zt" name="zutaten">;
                <?php
                $query = 'select zuei.zut_ein_id, ein.ein_name, zut.zut_name 
                          from einheit ein left outer join zutaten_einheiten zuei using(ein_id) left outer join zutaten zut 
                          using(zut_id) order by 1 asc;';
                $ingred = $con -> prepare($query);
                $ingred -> execute();
                while($row = $ingred -> fetch(PDO::FETCH_NUM))
                {
                    echo '<option value="'.$row[0].'">'.$row[1].' '.$row[2].'</option>';
                }
                ?>
            </select><br>
            <?php
        }
        ?>
        <label>Zubereitung</label>
        <input type="text" id="zub" name="zubereitung" size="100px"><br>
        <br>
        <input type="submit" name="saveIngred" value="speichern">
    </form>
    <?php
}
else if(isset($_POST['saveIngred']))
{
    $besch = $_POST['zubereitung'];
    //$lastPK = $con->lastInsertId();

    $query = 'insert into zubereitung (zub_beschreibung, rez_id) values(?, ?)';
    $stmt = $con -> prepare($query);
    $stmt -> execute([$besch, $con->lastInsertId()]);
}
else
{
    echo '<h1>Neues Rezept</h1>
          <p>Geben Sie Rezeptenamen und die Anzahl der Zutaten ein und klicken Sie auf speichern, 
          Sie werden dann weitergeleitet zum Zubereitung und Zutaten eingeben.</p>';
    ?>
    <form method="post">
        <br>
        <label for = "rn">Rezeptname:</label>
        <input type="text" id="rn" name="rName" placeholder = "z.B. Marillenknödel"><br>
        <label for = "nn">Anzahl der Zutaten: €</label>
        <input type="number" id="zut" name="zut" placeholder="z.B. 5"><br>
        <br>
        <input type="submit" name="saveit" value="speichern">
    </form>
    <?php
}