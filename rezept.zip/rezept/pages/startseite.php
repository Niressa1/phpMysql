<?php
echo '
<h1>Rezepte verwalten</h1>
<p>Bitte aus dem oberen Menü wählen</p>
<p>Seitendesign mit Bootstrap</p>
';
?>