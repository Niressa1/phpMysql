<?php
include ('config.php');
echo '<h1>Nach Rezepten suchen</h1>';

if (isset ($_POST['saveit']))
{

    $rez = $_POST['rezept'];
    echo '<h2>Gesucht wurde nach: '.$rez.'</h2>';
    ?>
    <form method="post">
        <label>Ergebnisliste der Suche: </label>
        <select id="zt" name="rezepte">
            <?php
            $query = "select rez_name from rezeptname where lower(rez_name) like lower('%".$rez."%');";
            $stmt = $con -> prepare($query);
            $stmt -> execute();
            while($row = $stmt -> fetch(PDO::FETCH_NUM))
            {
                echo '<option value="'.$row[0].'">'.$row[0].'</option>';
            }
            ?>
        </select>
        <br>
        <input type="submit" name="show" value="anzeigen">
    </form>
    <?php
}
else if(isset($_POST['show'])){

    $rez = $_POST['rezepte'];
    try {
        $query = "select rez.zubein_menge, ei.ein_name, zut.zut_name  
                            from rezept rez, rezeptname ren, zubereitung zub, zutaten_einheiten zutei, einheit ei, zutaten zut
                           where lower(ren.rez_name) like lower('%" . $rez . "%')
                             and zub.rez_id = ren.rez_id
                             and rez.zub_id = zub.zub_id
                             and zutei.zut_ein_id = rez.zut_ein_id
                             and ei.ein_id = zutei.ein_id
                             and zut.zut_id = zutei.zut_id";
        printTable($query);
    } catch (Exception $e) {
        echo $e->getCode() . ': ' . $e->getMessage();
    }

}
else
{
    ?>
    <form method="post">
        <br>
        <label for = "vn">Rezeptname (auch Wortteil möglich):</label>
        <input type="text" id="rez" name="rezept" placeholder = "z.B. kuchen"><br>
        <br>
        <input type="submit" name="saveit" value="speichern">
    </form>
<?php

}

function printTable($query)
{
    global $con;
    $stmt = $con -> prepare($query);
    $stmt -> execute();
    $columnCount = $stmt->columnCount();
    $meta = array(); //Informationen zu den Attributen als Array
    echo '<table border = "1"><tr>';
    for($i = 0; $i < $columnCount; $i++){
        $meta[] = $stmt -> getColumnMeta($i);
        echo '<th> ' .$meta[$i]['name'].' </th>';
    }
    echo '</tr>';
    while ($row = $stmt->fetch(PDO::FETCH_NUM))
    {
        echo '<tr> ';
        foreach($row as $r)
        {
            echo '<td> '.$r.' </td>';
        }
        echo ' </tr>';
    }
    echo '</table>';
}
?>