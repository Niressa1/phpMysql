<?php
if(isset($_GET['seite']))
{
    switch($_GET['seite'])
    {
        case 'hinzufuegen':
            echo '
            <li><a href="?seite=home">Startseite</a></li>
            <li class="active"><a href="?seite=hinzufuegen">Rezepte hinzufügen</a></li>
            <li><a href="?seite=suchen">Rezepte suchen</a></li>
            <li><a href="?seite=aendern">Rezepte ändern</a></li>';
            break;
        case 'suchen':
            echo '<li><a href="?seite=home">Startseite</a></li>
            <li><a href="?seite=hinzufuegen">Rezepte hinzufügen</a></li>
            <li class="active"><a href="?seite=suchen">Rezepte suchen</a></li>
            <li><a href="?seite=aendern">Rezepte ändern</a></li>';
                    break;
        case 'aendern':
            echo '
            <li><a href="?seite=home">Startseite</a></li>
            <li><a href="?seite=hinzufuegen">Rezepte hinzufügen</a></li>
            <li><a href="?seite=suchen">Rezepte suchen</a></li>
            <li class="active"><a href="?seite=aendern">Rezepte ändern</a></li>';
            break;
        default:
            echo '
            <li class="active"><a href="?seite=home">Startseite</a></li>
            <li><a href="?seite=hinzufuegen">Rezepte hinzufügen</a></li>
            <li><a href="?seite=suchen">Rezepte suchen</a></li>
            <li><a href="?seite=aendern">Rezepte ändern</a></li>';
    }
} else
{
    echo '
    <li class="active"><a href="?seite=home">Startseite</a></li>
    <li ><a href="?seite=hinzufuegen">Rezepte hinzufügen</a></li>
    <li><a href="?seite=suchen">Rezepte suchen</a></li>
    <li><a href="?seite=aendern">Rezepte ändern</a></li>';
}