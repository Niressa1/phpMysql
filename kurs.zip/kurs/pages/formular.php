<?php
echo '
<h1>Formular</h1>
<p>Erstellt mit PHP</p>';
echo '<h2> Kursverwaltung - Personen erfassen </h2>';
include ('config.php');
?>