<?php
echo '
<h1>PHP Seite</h1>
<p>Seitendesign mit Bootstrap</p>
';
?>