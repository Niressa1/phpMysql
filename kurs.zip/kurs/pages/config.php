<?php
/*Verbindung zur Datenbank herstellen */
$server = "localhost";
$user = "root";
$password = "";
$db = "kurs";

try
{
    $con = new PDO('mysql:host='.$server.';
            dbname='.$db.';
            charset=utf8', $user, $password);
    $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo 'Verbindung erstellt';
} catch ( Exception $e)
{
    echo $e->getMessage();
}
