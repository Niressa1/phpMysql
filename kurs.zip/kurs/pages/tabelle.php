<?php
echo '
<h1>Tabelle</h1>
<p>Erstellt mit PHP</p>
';
?>